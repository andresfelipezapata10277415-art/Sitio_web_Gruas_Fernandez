// ============================================================
// GRÚAS FERNÁNDEZ — CONFIGURACIÓN
// Cambia este correo por el correo real de la empresa.
// ============================================================
const COMPANY_EMAIL = "gruas.fernandez2026@gmail.com";

// Menú móvil
const navToggle = document.querySelector(".nav-toggle");
const navLinks = document.querySelector(".nav-links");

navToggle?.addEventListener("click", () => {
  const open = navLinks.classList.toggle("open");
  navToggle.setAttribute("aria-expanded", open ? "true" : "false");
});

document.querySelectorAll(".nav-links a").forEach(link => {
  link.addEventListener("click", () => navLinks.classList.remove("open"));
});

// Año automático
document.getElementById("year").textContent = new Date().getFullYear();

// Registro de servicio: genera un correo listo para enviar.
const form = document.getElementById("serviceForm");
const status = document.getElementById("formStatus");

form?.addEventListener("submit", (event) => {
  event.preventDefault();

  const data = new FormData(form);
  const name = data.get("name").trim();
  const phone = data.get("phone").trim();
  const service = data.get("service");
  const location = data.get("location").trim();
  const loadType = data.get("loadType").trim();
  const weight = data.get("weight").trim();
  const date = data.get("date");
  const message = data.get("message").trim();

  if (!name || !phone || !service || !location || !loadType || !weight || !date) {
    status.textContent = "Completa todos los campos obligatorios para preparar el registro del servicio.";
    return;
  }

  const subject = encodeURIComponent(`Registro de servicio — ${service}`);
  const body = encodeURIComponent(
`Hola, Grúas Fernández.

Quiero registrar y agendar un servicio.

DATOS DEL CLIENTE
Nombre: ${name}
Teléfono: ${phone}

DATOS DEL SERVICIO
Servicio: ${service}
Ubicación: ${location}
Tipo de carga: ${loadType}
Peso aproximado: ${weight}
Fecha requerida: ${date}

Detalles adicionales:
${message || "No se proporcionaron detalles adicionales."}

Enviado desde el sitio web de Grúas Fernández.`
  );

  window.location.href = `mailto:${COMPANY_EMAIL}?subject=${subject}&body=${body}`;
  status.textContent = "Abriendo tu aplicación de correo…";
});
